const axios = require('axios');

// Finds a place the user names and returns a WhatsApp map pin plus a Google Maps link.
// It does not track the sender or infer anyone's private location.
async function locationCommand(sock, from, msg, query = '') {
  const place = String(query || '').trim();
  if (!place) {
    return sock.sendMessage(from, {
      text: '📍 LOCATION COMMAND\n\nUse: .location <city or place>\nExample: .location Abbottabad\nExample: .location Faisal Mosque Islamabad\n\nMain aapki live location khud track nahi kar sakta. Kisi jagah ka naam likhein, ya WhatsApp se apni location khud share karein.'
    }, { quoted: msg });
  }

  try {
    const response = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: { q: place, format: 'jsonv2', limit: 1 },
      headers: { 'User-Agent': 'DARK-MD-Bot/1.0 (location search)' },
      timeout: 10000
    });
    const result = response.data && response.data[0];
    if (!result) {
      return sock.sendMessage(from, { text: `❌ Location nahi mili: ${place}\nCity ya place ka naam dobara check karein.` }, { quoted: msg });
    }

    const latitude = Number(result.lat);
    const longitude = Number(result.lon);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
      throw new Error('Invalid coordinates returned');
    }
    const mapUrl = `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;
    await sock.sendMessage(from, {
      location: { degreesLatitude: latitude, degreesLongitude: longitude, name: result.name || place, address: result.display_name || place }
    }, { quoted: msg });
    await sock.sendMessage(from, {
      text: `📍 LOCATION FOUND\n\n🏷️ ${result.display_name || place}\n🌐 Coordinates: ${latitude}, ${longitude}\n🗺️ Google Maps: ${mapUrl}`
    }, { quoted: msg });
  } catch (error) {
    console.error('Location command error:', error.message);
    await sock.sendMessage(from, { text: '⚠️ Location search abhi kaam nahi kar rahi. Internet/API unavailable ho sakti hai. Thori dair baad dobara try karein.' }, { quoted: msg });
  }
}

module.exports = locationCommand;
