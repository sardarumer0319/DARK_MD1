const yts = require('yt-search');

const TYPES = {
  movie: { label: 'Movie', search: q => `${q} official movie trailer`, emoji: '🎬' },
  cartoon: { label: 'Cartoon', search: q => `${q} official cartoon trailer`, emoji: '🧸' },
  drama: { label: 'Drama', search: q => `${q} official drama trailer`, emoji: '📺' }
};

async function mediaSearch(sock, chatId, message, query, type) {
  const config = TYPES[type];
  const q = (query || '').trim();
  if (!config) return;
  if (!q) {
    return sock.sendMessage(chatId, {
      text: `${config.emoji} *${config.label} Search*\nUse: .${type} <name>\nExample: .${type} Stranger Things\n\nThis command finds trailer/preview links; it does not download copyrighted full movies or episodes.`
    }, { quoted: message });
  }
  try {
    await sock.sendMessage(chatId, { react: { text: '🔎', key: message.key } });
    const result = await yts(config.search(q));
    const videos = (result && result.videos ? result.videos : []).slice(0, 5);
    if (!videos.length) {
      return sock.sendMessage(chatId, { text: `❌ ${config.label} ke results nahi mile. Naam dobara check karein.` }, { quoted: message });
    }
    const lines = videos.map((v, i) => `${i + 1}. *${v.title}*\n   Channel: ${v.author?.name || 'YouTube'}\n   Duration: ${v.timestamp || 'N/A'}\n   ${v.url}`).join('\n\n');
    return sock.sendMessage(chatId, {
      text: `${config.emoji} *${config.label} Search Results for:* ${q}\n\n${lines}\n\nℹ️ Ye trailer/preview search results hain. Full movies/episodes ke liye official ya licensed streaming services use karein.`
    }, { quoted: message });
  } catch (err) {
    console.error(`${type} search error:`, err.message);
    return sock.sendMessage(chatId, { text: `❌ ${config.label} search abhi kaam nahi kar rahi. Thori dair baad dobara try karein.` }, { quoted: message });
  }
}

module.exports = mediaSearch;
