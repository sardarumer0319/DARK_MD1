// Clearly simulated hacking-prank command. Does not access devices, accounts, or data.
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function fakeHackCommand(sock, chatId, message, q = '') {
  const target = String(q || 'DEMO SYSTEM').slice(0, 60);
  const steps = [
    '🎭 *FAKE HACK PRANK STARTED*',
    `🎯 Target label: ${target}`,
    '🖥️ Initializing fictional terminal...',
    '```[██░░░░░░░░] 20%```',
    '🌐 Simulating a connection... (DEMO ONLY)',
    '```[█████░░░░░] 50%```',
    '🔐 Simulating security scan...',
    '```[████████░░] 80%```',
    '```[██████████] 100%```',
    '✅ *SIMULATION COMPLETE*',
    '😂 *Just a prank!* No device, account, password, or private data was accessed.'
  ];
  try {
    for (const line of steps) {
      await sock.sendMessage(chatId, { text: line }, { quoted: message });
      await sleep(650);
    }
  } catch (err) {
    console.error('fakeHackCommand error:', err);
    await sock.sendMessage(chatId, { text: '❌ Fake hack demo could not finish.' }, { quoted: message });
  }
}

module.exports = fakeHackCommand;
