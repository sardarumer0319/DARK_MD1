async function aiCommand(sock, from, msg, isAdmin, session, args) {
    const action = (args[0] || '').toLowerCase();

    // Only the owner can toggle automatic replies; normal AI questions are available in chats.
    if (action === 'on' || action === 'off') {
        if (!isAdmin) {
            return sock.sendMessage(from, { text: '❌ Sirf bot owner AI auto-reply ko on/off kar sakta hai.' }, { quoted: msg });
        }
        session.aiEnabled = action === 'on';
        return sock.sendMessage(from, {
            text: action === 'on'
                ? '✅ AI auto-reply ON ho gaya. Private chat mein normal message bhej kar test karein.'
                : '✅ AI auto-reply OFF ho gaya.'
        }, { quoted: msg });
    }

    const query = args.join(' ').trim();
    if (!query) {
        return sock.sendMessage(from, {
            text: '🤖 DARK_MD AI\n\nUse: .ai <apna sawal>\nMisal: .ai Pakistan ke bare mein batao\n\nOwner only: .ai on / .ai off\nNote: AI API key configure hona zaroori hai.'
        }, { quoted: msg });
    }

    if (!process.env.OPENAI_API_KEY) {
        return sock.sendMessage(from, {
            text: '⚠️ AI API key set nahi hai. Hosting ke Environment Variables mein OPENAI_API_KEY add karo, phir bot restart karo.'
        }, { quoted: msg });
    }

    try {
        await sock.sendMessage(from, { react: { text: '🤖', key: msg.key } });
        const response = await session.getAIResponse(from, query);
        return sock.sendMessage(from, { text: response || 'AI se koi jawab nahi mila. Dobara koshish karein.' }, { quoted: msg });
    } catch (error) {
        console.error('AI command error:', error.message);
        return sock.sendMessage(from, { text: '❌ AI abhi jawab nahi de saka. API key, balance aur model settings check karein.' }, { quoted: msg });
    }
}

module.exports = aiCommand;
