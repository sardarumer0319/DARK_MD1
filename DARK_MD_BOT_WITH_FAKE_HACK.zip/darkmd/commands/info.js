// Shows only WhatsApp profile information that the connected account can access.
async function infoCommand(sock, from, msg, query = '') {
  try {
    const context = msg.message?.extendedTextMessage?.contextInfo || {};
    let target = context.mentionedJid?.[0] || context.participant;
    const number = String(query || '').replace(/[^0-9]/g, '');
    if (!target && number) target = `${number}@s.whatsapp.net`;
    if (!target) target = from.endsWith('@g.us') ? (msg.key.participant || msg.participant) : from;
    if (!target) {
      return sock.sendMessage(from, { text: 'Usage: .info <number> or reply/mention a user with .info\nExample: .info 923001234567' }, { quoted: msg });
    }
    const cleanNumber = target.split('@')[0].split(':')[0];
    let picture = null;
    try { picture = await sock.profilePictureUrl(target, 'image'); } catch (_) {}
    let about = 'Not publicly available';
    try {
      const status = await sock.fetchStatus(target);
      if (Array.isArray(status) && status[0]?.status) about = status[0].status;
    } catch (_) {}
    const lines = [
      '╭━━〔 WHATSAPP PUBLIC INFO 〕━━╮',
      `┃ 📱 Number: +${cleanNumber}`,
      `┃ 🔗 WhatsApp: https://wa.me/${cleanNumber}`,
      `┃ 📝 About: ${String(about).slice(0, 200)}`,
      `┃ 🖼️ Profile photo: ${picture ? 'Available to this account' : 'Hidden / unavailable'}`,
      '╰━━━━━━━━━━━━━━━━━━━━━━╯',
      '',
      'Note: Only information visible to this WhatsApp account is shown.'
    ];
    if (picture) {
      await sock.sendMessage(from, { image: { url: picture }, caption: lines.join('\n') }, { quoted: msg });
    } else {
      await sock.sendMessage(from, { text: lines.join('\n') }, { quoted: msg });
    }
  } catch (err) {
    console.error('Info command error:', err);
    await sock.sendMessage(from, { text: 'Could not fetch public WhatsApp profile information. The number may be invalid or privacy settings may block access.' }, { quoted: msg });
  }
}
module.exports = infoCommand;
