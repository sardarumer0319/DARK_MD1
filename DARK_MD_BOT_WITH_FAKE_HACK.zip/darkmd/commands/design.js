const sharp = require('sharp');

const STYLES = {
  advglow: {title:'ADVANCED GLOW', bg:['#070b2a','#5b21b6'], accent:'#8efcff', glow:true},
  amongus: {title:'AMONG US', bg:['#101827','#374151'], accent:'#fb7185', character:true},
  bplogo: {title:'BP LOGO', bg:['#061b35','#0e7490'], accent:'#facc15', logo:true},
  bpstyle: {title:'BP STYLE', bg:['#071b2d','#155e75'], accent:'#67e8f9', logo:true},
  clouds: {title:'CLOUDS', bg:['#60a5fa','#e0f2fe'], accent:'#ffffff', clouds:true},
  flag3d: {title:'3D FLAG STYLE', bg:['#052e16','#15803d'], accent:'#fef08a'},
  galaxy: {title:'GALAXY', bg:['#09051f','#581c87'], accent:'#e9d5ff', stars:true},
  galaxywp: {title:'GALAXY WALLPAPER', bg:['#020617','#312e81'], accent:'#c4b5fd', stars:true},
  glitch: {title:'GLITCH', bg:['#030712','#111827'], accent:'#fb7185', glitch:true},
  glow: {title:'GLOW', bg:['#030712','#164e63'], accent:'#67e8f9', glow:true},
  gradient: {title:'GRADIENT', bg:['#7c3aed','#ec4899'], accent:'#ffffff'},
  lightfx: {title:'LIGHT FX', bg:['#111827','#1d4ed8'], accent:'#fde68a', glow:true},
  logomaker: {title:'LOGO MAKER', bg:['#111827','#374151'], accent:'#fbbf24', logo:true},
  luxurygold: {title:'LUXURY GOLD', bg:['#09090b','#422006'], accent:'#facc15', gold:true},
  neon: {title:'NEON', bg:['#020617','#312e81'], accent:'#22d3ee', glow:true},
  papercut: {title:'PAPER CUT', bg:['#fce7f3','#c4b5fd'], accent:'#6d28d9'},
  pixelglitch: {title:'PIXEL GLITCH', bg:['#111827','#312e81'], accent:'#4ade80', glitch:true},
  royal: {title:'ROYAL', bg:['#1e1b4b','#581c87'], accent:'#fbbf24', gold:true},
  sand: {title:'SAND', bg:['#78350f','#fbbf24'], accent:'#fff7ed'},
  typography: {title:'TYPOGRAPHY', bg:['#18181b','#52525b'], accent:'#fafafa'},
  beach: {title:'BEACH', bg:['#0ea5e9','#fef3c7'], accent:'#ffffff'},
  underwater: {title:'UNDERWATER', bg:['#082f49','#0891b2'], accent:'#a5f3fc'},
  watercolor: {title:'WATERCOLOR', bg:['#fce7f3','#bfdbfe'], accent:'#7c3aed'},
  freecreate: {title:'FREE CREATE', bg:['#0f172a','#7c3aed'], accent:'#f0abfc', glow:true},
  write: {title:'TEXT ART', bg:['#111827','#334155'], accent:'#f8fafc'},
  cartoon: {title:'CARTOON STYLE', bg:['#f97316','#facc15'], accent:'#ffffff'}
};
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function svgFor(text, style) {
  const s = style || STYLES.freecreate; const safe = esc(text.slice(0, 70));
  const words = safe.length > 22 ? [safe.slice(0, Math.ceil(safe.length/2)), safe.slice(Math.ceil(safe.length/2))] : [safe];
  const font = safe.length > 32 ? 45 : safe.length > 20 ? 54 : 66;
  const lines = words.map((w,i)=>`<text x="600" y="${278 + i*78}" text-anchor="middle" font-family="Arial, sans-serif" font-size="${font}" font-weight="900" fill="${s.accent}" ${s.glow ? 'filter="url(#glow)"' : ''}>${w}</text>`).join('');
  let extras = '';
  if (s.stars) { for(let i=0;i<70;i++){let x=(i*137+31)%1200,y=(i*83+17)%600,r=(i%3)+1;extras+=`<circle cx="${x}" cy="${y}" r="${r}" fill="#fff" opacity="${0.25+(i%6)*0.1}"/>`;} }
  if (s.clouds) { extras = `<g fill="#fff" opacity=".72"><circle cx="190" cy="140" r="45"/><circle cx="235" cy="120" r="58"/><circle cx="285" cy="145" r="40"/><rect x="180" y="140" width="130" height="38" rx="19"/><circle cx="900" cy="470" r="35"/><circle cx="940" cy="450" r="48"/><circle cx="985" cy="472" r="30"/></g>`; }
  if (s.glitch) extras += `<text x="605" y="284" text-anchor="middle" font-family="Arial" font-size="${font}" font-weight="900" fill="#22d3ee" opacity=".75">${safe}</text><text x="595" y="292" text-anchor="middle" font-family="Arial" font-size="${font}" font-weight="900" fill="#fb7185" opacity=".75">${safe}</text>`;
  if (s.character) extras += `<g transform="translate(550 390)"><path d="M-65 -70 Q-65 -135 0 -135 Q65 -135 65 -70 L65 15 Q65 70 0 70 Q-65 70 -65 15Z" fill="#ef4444" stroke="#111827" stroke-width="12"/><rect x="-47" y="-85" width="95" height="55" rx="26" fill="#bae6fd" stroke="#111827" stroke-width="9"/><path d="M-55 40 L-90 70 M55 40 L90 70" stroke="#111827" stroke-width="18" stroke-linecap="round"/></g>`;
  if (s.logo) extras += `<path d="M600 125 L625 170 L680 178 L640 215 L650 270 L600 244 L550 270 L560 215 L520 178 L575 170Z" fill="${s.accent}" opacity=".92"/>`;
  const defs = `<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${s.bg[0]}"/><stop offset="1" stop-color="${s.bg[1]}"/></linearGradient><filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="8" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
  const title = `<text x="600" y="535" text-anchor="middle" font-family="Arial, sans-serif" font-size="24" font-weight="700" letter-spacing="6" fill="${s.accent}" opacity=".8">${esc(s.title)}</text>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="600" viewBox="0 0 1200 600">${defs}<rect width="1200" height="600" fill="url(#bg)"/>${extras}<rect x="32" y="32" width="1136" height="536" rx="30" fill="none" stroke="${s.accent}" stroke-opacity=".45" stroke-width="3"/>${lines}${title}</svg>`;
}
async function designCommand(sock, chatId, message, query, command) {
  if (command === 'deletetxt') {
    return sock.sendMessage(chatId, { text: '🧽 *.deletetxt*\nText removal from photos needs an image-editing/inpainting service. This ZIP does not include that service yet.\nUse: reply to a photo with .deletetxt after configuring a compatible image-edit API.' }, { quoted: message });
  }
  const text = (query || '').trim();
  if (!text) return sock.sendMessage(chatId, { text: `🎨 *${command.toUpperCase()} DESIGN*\nUse: .${command} Your Text\nExample: .${command} DARK MD` }, { quoted: message });
  try {
    const svg = Buffer.from(svgFor(text, STYLES[command] || STYLES.freecreate));
    const png = await sharp(svg).png().toBuffer();
    await sock.sendMessage(chatId, { image: png, caption: `✨ ${command.toUpperCase()} design\nText: ${text.slice(0,70)}` }, { quoted: message });
  } catch (e) {
    console.error('Design command error:', e.message);
    await sock.sendMessage(chatId, { text: '❌ Design image nahi ban saki. Hosting par sharp dependency install karke bot restart karein.' }, { quoted: message });
  }
}
module.exports = designCommand;
