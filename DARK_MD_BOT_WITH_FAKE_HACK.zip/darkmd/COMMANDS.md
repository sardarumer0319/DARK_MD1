# WhatsApp Commands

Ye commands project mein maujood hain. Prefix `.`, ya bot ke current parser ke mutabiq use karein.

- `.accept`
- `.ai`
- `.anticall`
- `.antidelete`
- `.antilink`
- `.antistatus`
- `.apk`
- `.autoreacts`
- `.autoread`
- `.autostatus`
- `.character`
- `.dp` / `.getpp` — profile picture of self, mentioned user, or replied user
- `.info <number>` / `.number <number>` — publicly visible WhatsApp profile details (number, About if visible, and profile photo if accessible)
- `.emojimix`
- `.facebook`
- `.gdrive`
- `.groupinfo`
- `.hack`
- `.hidetag`
- `.insta`
- `.instagram`
- `.joke`
- `.kick`
- `.kickoffline`
- `.meme`
- `.movie <name>` — search movie trailers/previews
- `.cartoon <name>` — search cartoon trailers/previews
- `.drama <name>` — search drama trailers/previews
- `.mf`
- `.owner`
- `.ping`
- `.private`
- `.public`
- `.setname`
- `.song`
- `.status`
- `.tagall`
- `.tiktok`
- `.translate`
- `.video`
- `.vv`

- `.uptime` is not included in this update.

## Important
- Owner/channel number aur channel link `settings.js` mein edit karein.
- API keys `.env` file mein rakhein; `.env` ko public na karein.
- Existing command files `commands/` folder mein hain.


### .setting <name>
Owner-only: changes only the bot display name. Channel link, owner name, and owner number stay fixed.


## Automatic video links
In public mode, sending a supported public TikTok, Instagram Reel/post, Facebook video, or YouTube link without a command makes the bot try to download and send the media automatically. Availability depends on the platform, privacy settings, downloader APIs, and WhatsApp media limits. Private/login-protected content is not supported.

### Movie / Cartoon / Drama Search
Use `.movie <name>`, `.cartoon <name>`, or `.drama <name>` to search YouTube for trailers/previews. These commands do not download full copyrighted movies or episodes. `.song <name>` is already included for song/audio search.


### Text / Logo Design Commands
These commands generate a local PNG design from the text supplied; they use SVG rendered through Sharp and do not require a paid image API. Examples: `.neon DARK MD`, `.luxurygold UMER`, `.amongus HELLO`, `.logomaker DARK MD`. Supported: `.advglow`, `.amongus`, `.bplogo`, `.bpstyle`, `.cartoon`, `.deletetxt`, `.clouds`, `.flag3d`, `.freecreate`, `.galaxy`, `.galaxywp`, `.glitch`, `.glow`, `.gradient`, `.lightfx`, `.logomaker`, `.luxurygold`, `.neon`, `.papercut`, `.pixelglitch`, `.royal`, `.sand`, `.typography`, `.beach`, `.underwater`, `.watercolor`, `.write`.

`.cartoon <text>` creates a cartoon-style text graphic; use `.cartoonsearch <name>` to search cartoon trailers. `.deletetxt` is registered but needs a compatible image inpainting API configured before it can remove text from an uploaded photo.

### Fake Hack Prank
- `.fakehack [label]` or `.prankhack [label]` runs a theatrical terminal-style simulation. It does not access devices, accounts, passwords, or private data.
