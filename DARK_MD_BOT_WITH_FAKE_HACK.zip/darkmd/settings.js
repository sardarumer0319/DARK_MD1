// ================= EDIT YOUR BOT DETAILS HERE =================
module.exports = {
    botName: 'DARK_MD',
    ownerName: 'Umer',
    // Write your WhatsApp number in international format, digits only.
    // Example: 923001234567
    ownerNumber: '923193360676',
    // Your WhatsApp Channel link.
    channelLink: 'https://whatsapp.com/channel/0029VbDC7GiKAwEoo54EPe2o',
    giphyApiKey: process.env.GIPHY_API_KEY || ''
};
