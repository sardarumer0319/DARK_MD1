# WhatsApp Automation Tool - DARK_MD

Professional WhatsApp Automation Tool with improved two-stage dashboard.

## Features

### Stage 1: Mobile Pairing (Initial Screen)
- Clean, minimal dashboard showing only:
  - Mobile number input field
  - "GENERATE PAIR CODE" button
  - Live console for logs

### Stage 2: Messaging (After Device Linking)
- Message type selector: Single or Multiple numbers
- **Single Number Mode**: Send to one number with custom speed
- **Multiple Numbers Mode**: Add multiple numbers and send bulk messages
- File upload for messages
- Live progress tracking
- Connection status display
- Logout option

## Installation

### Prerequisites
- Node.js 16+ 
- npm or yarn

### Setup

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Configure Environment**
   - Edit `.env` file if needed (default PORT: 22019)

3. **Start Server**
   ```bash
   npm start
   ```
   
   Or for development with auto-reload:
   ```bash
   npm run dev
   ```

4. **Access Application**
   - Open browser: `http://localhost:22019`

## Usage

### Step 1: Initial Screen - Mobile Pairing
1. You will see only the mobile number input field
2. Enter your WhatsApp mobile number (e.g., 923052062145)
3. Click "GENERATE PAIR CODE"
4. Copy the 8-digit code from the console
5. Open WhatsApp > Settings > Linked Devices > Link with phone number
6. Enter the pairing code

### Step 2: After Linking - New Dashboard
Once your device is successfully linked, the dashboard will automatically change to show:
- **SELECT MESSAGE TYPE** section with two options:
  - 📱 SINGLE NUMBER
  - 👥 MULTIPLE NUMBERS

#### Single Number Mode
- Enter victim number
- Set speed (minimum 5 seconds)
- Upload message file (.txt)
- Click "START NOW"

#### Multiple Numbers Mode
- Add multiple numbers one by one using the "+ ADD" button
- Set speed (minimum 5 seconds)
- Upload message file (.txt)
- Click "START NOW"

### Step 3: Monitor Progress
- Watch live console for real-time updates
- View statistics: Rounds, Sent, Failed
- Click "STOP SENDING" to halt the process

## File Format

### Message File (.txt)
Create a `.txt` file with your message content:
```
Hello! This is an automated message.
Please reply if you receive this.
```

## API Endpoints

- `POST /api/pair` - Request pairing code
- `POST /api/start-send` - Start sending messages
- `POST /api/stop-send` - Stop sending messages
- `POST /api/upload-numbers` - Upload numbers file
- `GET /api/status` - Get connection status
- `POST /api/logout` - Logout from WhatsApp

## Important Notes

- **Two-Stage Design**: Stage 1 shows only pairing; Stage 2 appears after successful linking
- **Minimum delay**: 5 seconds between messages (anti-ban protection)
- **Auto-cleaning**: Phone numbers are automatically formatted
- **Session credentials**: Saved locally in `auth_info/` directory
- **Continuous sending**: Messages continue until stopped
- **File uploads**: Temporary files are deleted after use

## Troubleshooting

### Connection Issues
- Check console for detailed error messages
- Re-pair if connection drops
- Ensure WhatsApp is properly linked

### Pairing Code Not Appearing
- Wait 5-10 seconds after clicking "GENERATE PAIR CODE"
- Check browser console for errors
- Try with a different number

### Messages Not Sending
- Verify WhatsApp is properly linked
- Check that numbers are valid
- Ensure message file is in `.txt` format
- Review console logs for specific errors

## Branding

Powered by **USMAN TECH**

[Join WhatsApp Channel](https://whatsapp.com/channel/0029VbDC7GiKAwEoo54EPe2o)

## License

For DARK_MD use only.

## Editable Settings
Edit `settings.js` to add your own:
- WhatsApp owner number
- Owner name
- Bot name
- WhatsApp Channel link

See `EDIT_HERE.txt` and `COMMANDS.md`.


### Added commands (Umer update)
- `.info <number>` or `.number <number>` — shows only WhatsApp profile information visible to the bot account, including About when available and profile photo when accessible.
- `.dp` or `.getpp` — gets a profile photo for the sender, a replied-to user, or a mentioned user.

Privacy note: these commands do not reveal private SIM-owner records, CNIC data, live location, or hidden account information.


### Automatic video link download
In public mode, send a supported public TikTok, Instagram, Facebook, or YouTube video link directly in WhatsApp; the bot will attempt to download and send the media without needing a command. It depends on external downloader services and does not work for every link or private content.


## DARK_MD: AI + automatic public video links

### AI setup
1. Copy `.env.example` to `.env`.
2. Set `OPENAI_API_KEY` to your own API key. Never share or upload `.env`.
3. Keep `AI_BASE_URL=https://api.openai.com/v1` for OpenAI, or set a compatible provider URL.
4. Start the bot with `npm install` then `npm start`. Use `.ai <question>` to ask a question. Use `.ai on` / `.ai off` to toggle automatic replies (owner only). API usage may cost money.

### Automatic video links
Set the bot to public mode with `.public` from the owner account. Then send a supported public TikTok, Instagram, Facebook, or YouTube link to the bot chat. The bot attempts to download it automatically; external downloader APIs can fail, and private/login-protected content is not supported. Use only content you have permission to download.

### Deployment
This ZIP is prepared for deployment but has **not** been deployed to a hosting account. On a Node.js host, upload/extract the project, run `npm install`, configure the environment variables (especially `OPENAI_API_KEY` if using AI), and run `npm start`. The host must keep the process alive and provide persistent storage for the WhatsApp auth/session files. Do not share pairing codes or session files.


## AI setup (DARK_MD)

1. Copy `.env.example` to `.env` for local hosting, or add the variables below in your host's Environment Variables panel.
2. Set `OPENAI_API_KEY` to your own API key from your chosen OpenAI-compatible provider. Do not share the key or commit `.env`.
3. Keep `AI_BASE_URL=https://api.openai.com/v1` for OpenAI, or use the provider's compatible API URL. Set `AI_MODEL` to a model supported by that provider.
4. Install dependencies with `npm install`, then start with `npm start`.

WhatsApp commands:
- `.ai <question>` — ask AI a question.
- `.ai on` — owner-only: enable AI auto-replies to ordinary messages in private chats for the current running session.
- `.ai off` — owner-only: disable AI auto-replies.

AI requires a valid API key and may incur provider charges. This ZIP has not been deployed to a hosting account; configure the key and test the bot after deployment.


Media search commands added: `.movie <name>`, `.cartoon <name>`, `.drama <name>`. They return trailer/preview links. `.song <name>` is already available for music search.

## Fake hack prank
Use `.fakehack [label]` or `.prankhack [label]` for a clearly labeled fictional terminal animation. It performs no real hacking and does not collect or access data.
